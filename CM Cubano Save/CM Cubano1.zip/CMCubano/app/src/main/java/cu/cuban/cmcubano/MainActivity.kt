package cu.cuban.cmcubano

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.tooling.preview.Preview
import cu.cuban.cmcubano.screens.*
import cu.cuban.cmcubano.ui.theme.CMCubanoTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CMCubanoTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    MainScreen()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen() {
    var selectedRoute by remember { mutableStateOf("inicio") }
    
    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Home, contentDescription = "Inicio") },
                    label = { Text("Inicio") },
                    selected = selectedRoute == "inicio",
                    onClick = { selectedRoute = "inicio" }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Build, contentDescription = "Útiles") },
                    label = { Text("Útiles") },
                    selected = selectedRoute == "utiles",
                    onClick = { selectedRoute = "utiles" }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Info, contentDescription = "Datos") },
                    label = { Text("Datos") },
                    selected = selectedRoute == "datos",
                    onClick = { selectedRoute = "datos" }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Map, contentDescription = "Mapa") },
                    label = { Text("Mapa") },
                    selected = selectedRoute == "mapa",
                    onClick = { selectedRoute = "mapa" }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Settings, contentDescription = "Ajustes") },
                    label = { Text("Ajustes") },
                    selected = selectedRoute == "ajustes",
                    onClick = { selectedRoute = "ajustes" }
                )
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (selectedRoute) {
                "inicio" -> InicioScreen()
                "utiles" -> UtilesScreen()
                "datos" -> DatosScreen()
                "mapa" -> MapaScreen()
                "ajustes" -> AjustesScreen()
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun MainScreenPreview() {
    CMCubanoTheme {
        MainScreen()
    }
}