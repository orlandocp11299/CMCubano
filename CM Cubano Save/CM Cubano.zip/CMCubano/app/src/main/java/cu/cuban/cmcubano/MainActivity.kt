package cu.cuban.cmcubano

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Build
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import cu.cuban.cmcubano.navigation.NavigationRoutes
import cu.cuban.cmcubano.ui.theme.CellMapperCubanoTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CellMapperCubanoTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    MainScreen()
                }
            }
        }
    }
}

@Composable
fun MainScreen() {
    var selectedRoute by remember { mutableStateOf(NavigationRoutes.INICIO) }
    
    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Home, contentDescription = "Inicio") },
                    label = { Text("Inicio") },
                    selected = selectedRoute == NavigationRoutes.INICIO,
                    onClick = { selectedRoute = NavigationRoutes.INICIO }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Build, contentDescription = "Útiles") },
                    label = { Text("Útiles") },
                    selected = selectedRoute == NavigationRoutes.UTILES,
                    onClick = { selectedRoute = NavigationRoutes.UTILES }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Storage, contentDescription = "Datos") },
                    label = { Text("Datos") },
                    selected = selectedRoute == NavigationRoutes.DATOS,
                    onClick = { selectedRoute = NavigationRoutes.DATOS }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Map, contentDescription = "Mapa") },
                    label = { Text("Mapa") },
                    selected = selectedRoute == NavigationRoutes.MAPA,
                    onClick = { selectedRoute = NavigationRoutes.MAPA }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Settings, contentDescription = "Ajustes") },
                    label = { Text("Ajustes") },
                    selected = selectedRoute == NavigationRoutes.AJUSTES,
                    onClick = { selectedRoute = NavigationRoutes.AJUSTES }
                )
            }
        }
    ) { paddingValues ->
        Box(modifier = Modifier.padding(paddingValues)) {
            when (selectedRoute) {
                NavigationRoutes.INICIO -> Text("Pantalla de Inicio")
                NavigationRoutes.UTILES -> Text("Pantalla de Útiles")
                NavigationRoutes.DATOS -> Text("Pantalla de Datos")
                NavigationRoutes.MAPA -> Text("Pantalla de Mapa")
                NavigationRoutes.AJUSTES -> Text("Pantalla de Ajustes")
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun MainScreenPreview() {
    CellMapperCubanoTheme {
        MainScreen()
    }
}