package cu.cuban.cmcubano.navigation

enum class NavigationRoutes {
    INICIO,
    UTILES,
    DATOS,
    MAPA,
    AJUSTES
} 